# ChatGPT Prompts for Contract Clause Analysis

## Structure Extraction
"Please extract and summarize each clause in this contract. For each clause, provide: title, purpose, typical usage, and potential legal risk."

## Translation
"Translate the following clause into plain Japanese legal language suitable for inclusion in a bilingual contract. Then explain any key legal terms."

## Comparison
"Compare this clause to a typical Japanese NDA clause and highlight the differences in legal scope and enforceability."
