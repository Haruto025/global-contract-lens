# 🌐 Global Contract Lens (GCL)

An open legal intelligence project that visualizes, annotates, and compares multilingual contract clauses across jurisdictions using AI (ChatGPT, Claude). Built by a Japanese law student with expertise in law, English, and AI.

---

## 📌 Project Summary（プロジェクト概要）

**Global Contract Lens（GCL）**は、実際の英語契約書（NDAなど）を対象に、条項をAIで分解・注釈・翻訳し、構造化データベースとして可視化するプロジェクトです。

本リポジトリでは以下の成果物を公開しています：

- ✅ 契約条項の分類・構造データ（CSV形式）
- ✅ 英文契約の日本語対訳付きデータ
- ✅ プロンプト集（ChatGPT用）
- ✅ Notionなどで使えるテンプレ

---

## 📂 Files

- `/data/GCL_clause_translation_sample.csv`：構造化済みの契約条項対訳データ（2条項分）
- `/prompts/`：AIに条項を分解・注釈させるプロンプト例
- `/images/`：データベースやUIの例（任意）

---

## 🎯 Use Cases

- 法学部・ロースクール生：英語契約の構造学習と比較法演習に
- 企業法務担当者：実例ベースの条項チェック
- 研究者：契約構造と比較法の定量分析
- 翻訳者：法務翻訳の参考資料として活用

---

## 👨‍💻 Author

📎 Haruto  
A university student in Japan exploring the intersection of law, language, and AI.  
Contact via GitHub Issues or note: [noteリンクを後で追記]

---

## 🪪 License

MIT License.
